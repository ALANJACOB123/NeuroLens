# Setup Instructions

1. Install requirements
2. Run acquisition
